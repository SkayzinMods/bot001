const welcome = (number, groupname) => {
    return `Aopa @${number}. bem vindo a essa porra ${groupname}`
}
exports.welcome = welcome

const bye = (number) => {
    return `Tchau @${number}. vai embora porrakkk `
}
exports.bye = bye