const nethunter = () => {
return `O kali nethunter é um programa que simula o terminal do kali linux no seu termux
o kali linux é um sistema operacional voltado mais para segurança e invasão de computadores
com diversos programas e ferramentas de invasão e defesa, uma grande maioria dos hackers utiliza
esse sistema, o kali nethunter criado pela própia empresa simula essa OS para o terminal android
segue o link para poder instalar o kali nethunter no seu termux:

🔰 Kali-Nethunter: https://enrt.eu/UDXILze 🔰`

}
exports.nethunter = nethunter