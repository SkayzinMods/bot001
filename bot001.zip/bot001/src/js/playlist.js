const playlist = (p) => {
    return `.•♫•♬• ༻🔊 𝙿𝚕𝚊𝚢𝚕𝚒𝚜𝚝 🔊༺ •♫•♬•
｡☆✼★━━━━━━ - ━━━━━━★✼☆｡
❁❧ *${p}m4*
M4
❁❧ *${p}paypal*
PayPal 💰
❁❧ *${p}mood*
24kGoldn - Mood (Lyrics) ft. Iann Dior
❁❧ *${p}bebelean*
LEAN - Superiority x Towy x Osquel x Beltito x Sammy x Falsetto
❁❧ *${p}raputin*
Nightcore - Rasputin (Remix) (For Mother Russia)
❁❧ *${p}moskau*
Nightcore - Moskau
❁❧ *${p}kalinka*
Nightcore - Kalinka [Калинка]
❁❧ *${p}katyusha*
[HARDBASS] Katyusha (Cosmowave Remix)
❁❧ *${p}yamete*
Yamete kudasai
❁❧ *${p}tuebaiano*
777-666 (Baiano Edition) - Lil Jappz (@caiojapa71)
❁❧ *${p}pneublind*
CHEIRO DE BLINDING LIGHTS | LEOD
❁❧ *${p}cunouno*
VOU COMER SEU C* NO UNO - CLIPE OFICIAL - MC Renanzin (Clipe Oficial)
❁❧ *${p}polishcow*
POLISH COW
❁❧ *${p}urss*
HINO DA U.R.S.S
❁❧ *${p}amgdamuie*
Amiga Da Minha Mulher - Seu Jorge
❁❧ *${p}bcupernbam*
NEGO BAM - BUTTERCUP | LEOD
❁❧ *${p}dstartnowpneu*
CHEIRO DE DON'T START NOW OU CHEIRO DE TAMBORZINHO | LEOD
❁❧ *${p}wthisdown*
SoulChef - Write This Down (Feat. Nieve)
❁❧ *${p}hentaigirl*
MTC-S3RL
❁❧ *${p}hentaigirl2*
S3RL-MTC2
❁❧ *${p}diekpop*
Rapxis - Kpooper me Cancelou (Prod. H'erick)
❁❧ *${p}ilovedarla*
Rapxis & Gohann - i Love Darla (prod. Astrobeattz)
❁❧ *${p}autistar*
Rapxis - Autistar ( Prod. pdr0sa )
❁❧ *${p}shitpostgirl*
Rapxis - Mina Shitposter (feat. Gohann)
❁❧ *${p}ftuberculose*
Rapxis & Gohann - Flow Tuberculose (prod. YungDrum)
❁❧ *${p}goticrabuda*
Rapxis - Gótica Rabuda (Feat. Libiuz)
❁❧ *${p}yougirlistenme*
Rapxis - Sua Mina Me Escuta 🎧 (Prod. Gohann)`
}
exports.playlist = playlist