const pack = (date, user, wame) => {
return `┏━🔥 𝚘𝚜 𝚖𝚎𝚕𝚎𝚌𝚊 𝚙𝚎𝚒𝚍𝚊 𝚋𝚊𝚒𝚡𝚒𝚗 🔥━┓
║                                                           
║ _*🕐 Data e Hora: ${date} 🕐*_
║ _*🙂 User: ${user} 🙂*_
║ _*🌎 Link: ${wame} 🌎*_                                        
║                                                           
┣══════𝑺𝒊𝒈𝒂 𝒏𝒂𝒔 𝒓𝒆𝒅𝒆𝒔 𝒔𝒐𝒄𝒊𝒂𝒊𝒔══════┫
║
║ _*📷 Instagram:*_ wtfskayzinkkkj
║
║ _*📹 Youtube:*_
║ _*🌐https://youtube.com/channel/UCTmpZp-8MAJTYq2uGFo92wQ 🌐*_
║
┗════════════════════════┛
» 🥵𝙾𝚗𝚕𝚢𝚏𝚊𝚗𝚜 𝚎 𝚑𝚎𝚗𝚝𝚊𝚒 𝚗𝚘 𝚖𝚎𝚐𝚊🥵 «

❁❧ *FOTOS DE HENTAI 720MB:* 
_*🌐 https://suaurl.com/55eb2f 🌐*_

❁❧ *PRINCESS STARLING(ONLY FANS)8.36GB:* 
_*🌐 https://suaurl.com/b995e2 🌐*_

❁❧ *ELLES CLUB 28.68GB:* 
_*🌐 https://suaurl.com/8c135b 🌐*_

❁❧ *COCONUTKITTY(ONLY FANS)7.69GB:*
_*🌐 https://suaurl.com/5e91e0 🌐*_

❁❧ *Belle delphine:* 
_*🌐 https://suaurl.com/5c699d 🌐*_

❁❧ *Love Lilah:* 
_*🌐 https://suaurl.com/dbaae7 🌐*_

❁❧ *Hidori:* 
_*🌐 https://suaurl.com/f43f76 🌐*_`
}
exports.pack = pack
